/*
 * @Author: 大柒
 * @QQ: 531310591@qq.com
 * @Date: 2020-06-04 00:34:11
 * @Version: Auto.Js Pro
 * @Description:
 * @LastEditors: 大柒
 * @LastEditTime: 2020-06-04 00:34:12
 */

importClass(android.os.Build);
importClass(android.view.View);
importClass(android.view.Gravity);
importClass(android.view.ViewGroup);
importClass(android.view.WindowManager);
importClass(android.view.inputmethod.EditorInfo);
importClass(android.widget.TextView);
importClass(android.widget.PopupWindow);
importClass(android.widget.RelativeLayout);
importClass(android.graphics.Color);
importClass(android.graphics.Typeface);
importClass(android.graphics.drawable.BitmapDrawable);
importClass(android.graphics.drawable.StateListDrawable);
importClass(android.graphics.drawable.GradientDrawable);
importClass(android.transition.Slide);
importClass(android.transition.Visibility);
importClass(android.animation.ValueAnimator);
importClass(android.animation.StateListAnimator);
importClass(android.view.animation.OvershootInterpolator);
importClass(android.view.animation.AnticipateInterpolator);

var activity = ui.getActivity();
var decorView = activity.getWindow().getDecorView();
var rootView = (activity.findViewById(android.R.id.content)).getChildAt(0);
var resources = context.getResources();
var random = new java.util.Random();

var scale = resources.getDisplayMetrics().density;
var dp2px = function (dp) {
    return Math.floor(dp * scale + 0.5);
};
var px2dp = function (px) {
    return Math.floor(px / scale + 0.5);
};

decorView.getChildAt(0).getChildAt(1).setFitsSystemWindows(true);

//activity.window.addFlags(View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
activity.getWindow().setStatusBarColor(Color.TRANSPARENT);//状态栏颜色
activity.getWindow().setNavigationBarColor(0xFAFAFA);//导航栏颜色
SystemUiVisibility(false);//设置暗色系状态栏

function main() {
    ui.layout("参数设置", "main.xml");
    ui.layout("其他说明", "main2.xml");
    activity.findViewById(getResourceID('header_layout', 'id')).setVisibility(8);
    activity.findViewById(getResourceID('tl', 'id')).setVisibility(8);

    //创建开始按钮
    new CreateImageButton(ui.findViewByTag('main2_layout'), function (btn) {
        btn.setText('启动脚本');
        btn.setTextColor('#FAFAFA');
        btn.setPadding(10, 5, 10, 5);
        btn.setTypeface('monospace');
        //点击事件
        btn.onClick(function (view) {
            ui.start();//启动脚本
        });

        let view = btn.getView();
        let params = view.getLayoutParams();
        params.width = ViewGroup.LayoutParams.WRAP_CONTENT;//控件宽度
        params.gravity = Gravity.CENTER;//layout_gravity;
        view.setLayoutParams(params);
        view.setTranslationZ(10);

        //视图状态动画
        let gd = new CreateShape(dp2px(5), 0, null);
        //设置背景图片
        view.setBackground(gd);
        //抬起颜色 按下颜色
        let colors = [str2argb('#1e88e5'), str2argb('#1565c0')];
        //设置可点击
        view.setClickable(true);
        //0~1浮数点 当前动画进度
        let fraction = 0;
        //动画回调接口
        let addUpdateListener = {
            onAnimationUpdate: function (animation) {
                fraction = animation.getAnimatedValue();
                //过度颜色
                let color = ColorEvaluator(fraction, colors[0], colors[1]);
                gd.setColor(Color.parseColor(color));
                view.setBackground(gd);
                //缩放
                let scale = 1 - 0.1 * fraction;
                view.setScaleX(scale);
                view.setScaleY(scale);
            }
        };
        //按下动画
        let pressedAnim = ValueAnimator.ofFloat(0, 1);
        pressedAnim.setDuration(100);
        pressedAnim.addUpdateListener(addUpdateListener);
        //抬起动画
        let normalOffAnim = ValueAnimator.ofFloat(1, 0);
        normalOffAnim.setDuration(100);
        normalOffAnim.addUpdateListener(addUpdateListener);
        //状态动画集合
        let mStateListAnimator = new StateListAnimator();
        mStateListAnimator.addState([android.R.attr.state_pressed], pressedAnim);//按下
        mStateListAnimator.addState([-android.R.attr.state_pressed], normalOffAnim);//- 反之抬起

        view.stateListAnimator = mStateListAnimator;
    });

    /**
     * 侧边栏
     */
    //初始化相对布局
    initRelativeLayout();
    //ViewPager
    var viewpager = activity.findViewById(getResourceID('vp', 'id'));
    viewpager.setBackgroundColor(Color.parseColor('#426e6d'));
    viewpager.overScrollMode = View.OVER_SCROLL_NEVER;//删除滑动到底的阴影
    viewpager.currentItem = 1;//跳转第二页
    viewpager.setPageTransformer(true, new MyPageTransform());
    viewpager.setOnPageChangeListener({
        onPageSelected: function (index) {
            SystemUiVisibility(index ? false : true);
        }
    });

    //PopupWindow对话框
    var personal = new PopPersonal();
    //仿Toolbar
    var status_bar_height = resources.getDimensionPixelSize(resources.getIdentifier("status_bar_height", "dimen", "android"));
    ui.toolbar.setPadding(dp2px(20), status_bar_height, dp2px(20), 0);
    ui.setEvent(ui.toolbar, 'click', function (view) {
        //弹出对话框
        personal.show(function (value, user, pw) {
            if (value) {
                ui.toast('你输入的内容为\n用户名: ' + user + '\n密码: ' + pw);
            }
        });
    });
    //创建侧边栏按钮列表
    var buttons = [{//按钮数据
        text: 'Adoption',
        icon: 'ic_pets_black_48dp'
    }, {
        text: 'Donation',
        icon: 'ic_folder_shared_black_48dp'
    }, {
        text: "Add pet",
        icon: "ic_games_black_48dp"
    }, {
        text: "Favorites",
        icon: "ic_favorite_black_48dp"
    }, {
        text: "Messages",
        icon: "ic_email_black_48dp"
    }, {
        text: "Profile",
        icon: "ic_person_black_48dp"
    }];
    for (i in buttons) {
        new CreateImageButton(ui.item, function (btn) {
            btn.setText(buttons[i].text)
            btn.setTextColor('#FFFFFF');
            btn.setTypeface('monospace');
            btn.setPadding(20, 12, 20, 12);
            btn.setLeftDrawable(buttons[i].icon, 16, '#FFFFFF', 10);
            btn.setBackgroundRes('notification_action_background');
            btn.onClick(item_onClick);
        });
    }

    function item_onClick(view, text) {
        ui.toast("你点击了" + text);
    }

    //创建设置按钮
    new CreateImageButton(ui.bottom_layout, function (btn) {
        btn.setText('Settings')
        btn.setTextColor('#FFFFFF');
        btn.setTypeface('monospace');
        btn.setPadding(20, 15, 20, 15);
        btn.setLeftDrawable('ic_settings_black_48dp', 16, '#FFFFFF', 10);
        btn.setBackgroundRes('notification_action_background');
        btn.onClick(function (view) {
            ui.openECSystemSetting();
        });
    }, true);
    //创建退出按钮
    new CreateImageButton(ui.bottom_layout, function (btn) {
        btn.setText('Exit')
        btn.setTextColor('#FFFFFF');
        btn.setTypeface('monospace');
        btn.setPadding(20, 15, 20, 15);
        btn.setBackgroundRes('notification_action_background');
        btn.onClick(function (view) {
            exit();//退出脚本
        });
    });

}


//获取内置资源ID
function getResourceID(name, type) {
    //context.getResources().getIdentifier(name, type, context.getPackageName()');//废弃打包后无法获取内置资源
    return context.getResources().getIdentifier(name, type, 'com.gibb.easyclick');
}

//通知栏改变主题
function SystemUiVisibility(value) {
    var option = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | (value ? View.SYSTEM_UI_FLAG_LAYOUT_STABLE : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
    activity.getWindow().getDecorView().setSystemUiVisibility(option);
}

/**
 *ViewPager 自定义动画
 */
function MyPageTransform() {
    var dp30 = dp2px(30);
    var radius = 0;
    var pageWidth;
    var main2_root = ui.findViewByTag('main2_root');
    var gd = new GradientDrawable();
    var params = ui.item_layout.getLayoutParams();
    gd.setCornerRadius(radius);
    gd.setColor(Color.parseColor('#FAFAFA'));
    main2_root.setBackground(gd);
    this.transformPage = (function (view, position) {
        pageWidth = view.getWidth();
        if (position < -1) {
            view.setAlpha(0);
        } else if (position <= 0) {
            view.setTranslationX(pageWidth * position);
        } else if (position <= 1) {
            view.setTranslationX((pageWidth * 0.5) * -position);
            view.setScaleX(1 - (0.3 * position));
            view.setScaleY(1 - (0.3 * position));
            if (radius != parseInt(dp30 * position)) {//圆角切换
                gd.setCornerRadius((radius = parseInt(dp30 * position)));
                main2_root.setBackground(gd);
            }
            if (position == 1) {//设置list 宽度
                params.width = parseInt(pageWidth * 0.65);
                ui.item_layout.setLayoutParams(params);
            }
            ;
        } else {
            view.setAlpha(0);
        }
    });
};

/**
 *创建图标按钮
 */
function CreateImageButton(parent, callback, isTop) {
    isTop = isTop || false
    var ld = null;
    var tv = new TextView(context);
    var mClickCallback = function () {
    };
    var paint = tv.getPaint();
    var typeface = {
        'default': Typeface.DEFAULT,
        'sans': Typeface.SANS_SERIF,
        'serif': Typeface.SERIF,
        'monospace': Typeface.MONOSPACE
    }
    parent.addView(tv, isTop ? 0 : -1);
    tv.setOnClickListener({
        onClick: function () {
            mClickCallback(tv, tv.getText())
        }
    });

    this.getView = function () {
        return tv;
    }

    this.setText = function (str) {
        tv.setText(str);
    }

    this.setTextSize = function (number) {
        tv.setTextSize(number);
    }

    this.setTextColor = function (colorstr) {
        tv.setTextColor(Color.parseColor(colorstr));
    }

    this.setBold = function (isBold) {
        paint.setFakeBoldText(isBold);
    }

    this.setTypeface = function (str) {
        tv.setTypeface(typeface[str]);
    }

    this.setPadding = function (l, t, r, b) {
        let hasMeasured = false;
        if (tv.getMeasuredHeight() != 0) {
            tv.setPadding(dp2px(l), dp2px(t), dp2px(r), dp2px(b));
        } else {
            tv.getViewTreeObserver().addOnPreDrawListener({
                onPreDraw: function () {
                    if (hasMeasured == false && tv.getMeasuredHeight() != 0) {
                        hasMeasured = true;
                        tv.getViewTreeObserver().addOnPreDrawListener({
                            onPreDraw: function () {
                                return true;
                            }
                        });
                        tv.setPadding(dp2px(l), dp2px(t), dp2px(r), dp2px(b));
                    }
                    return true;
                }
            });
        }
    }

    this.setLeftDrawable = function (resName, size, colorstr, padding) {
        if (ld != null) ld.recycle();
        ld = ui.resResAsDrawable('drawable/' + resName + '.png');
        ld.setBounds(0, 0, dp2px(size), dp2px(size));
        ld.setTint(Color.parseColor(colorstr));
        tv.setCompoundDrawables(ld, null, null, null);
        tv.setCompoundDrawablePadding(dp2px(padding));
    }

    this.setBackgroundRes = function (resName) {
        tv.setBackground(context.getResources().getDrawable(getResourceID(resName, 'drawable')));
    }

    this.onClick = function (callback) {
        mClickCallback = callback;
    }

    callback(this);
}

/**
 * 创建ShapeDrawable
 * @param roundRadius
 * @param shape
 * @param fillColor
 * @param stroke
 * @returns {GradientDrawable}
 * @constructor
 */
function CreateShape(roundRadius, shape, fillColor, stroke) {
    stroke = stroke || null;
    if (stroke != null && stroke[1] != "") stroke[1] = Color.parseColor(stroke[1]);
    fillColor = Color.parseColor((fillColor != null && fillColor != "") ? fillColor : "#00000000");
    var gd = new GradientDrawable();
    gd.setColor(fillColor);
    gd.setShape(shape != -1 ? GradientDrawable.LINEAR_GRADIENT : shape);
    if (roundRadius != -1) gd.setCornerRadius(roundRadius);
    if (stroke != null && stroke[0] != -1) gd.setStroke(stroke[0], stroke[1], stroke[2] = stroke[2] || 0, stroke[3] = stroke[3] || 0);
    return gd;
}

/**
 * 初始化相对布局属性
 */
function initRelativeLayout() {
    var view = ui.item_layout;
    //给控件设置id
    ui.toolbar.setId(1000 + random.nextInt(1000));
    ui.bottom_layout.setId(1000 + random.nextInt(1000));
    //获取布局参数
    var params = view.getLayoutParams();
    //设置布局 above属性 和 below属性
    params.addRule(RelativeLayout.ABOVE, ui.bottom_layout.getId());
    params.addRule(RelativeLayout.BELOW, ui.toolbar.getId());
    //设置布局底部对齐
    var params_1 = ui.bottom_layout.getLayoutParams();
    params_1.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
    ui.bottom_layout.setLayoutParams(params_1);
}

/**
 * PopupWindow 对话框
 */
function PopPersonal() {
    var pv = ui.parseView('layout_personal.xml');
    var lp = activity.getWindow().getAttributes();
    var pw = new PopupWindow(pv, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    var dm = new android.util.DisplayMetrics();
    activity.getWindowManager().getDefaultDisplay().getMetrics(dm);
    var w = dm.widthPixels;
    var root_view = ui.findViewByTag('pop_personal_root');
    var ppl = ui.findViewByTag('pop_personal_layout');
    var user_input = ui.findViewByTag('pop_personal_user');
    var pw_input = ui.findViewByTag('pop_personal_pw');
    var cancel = ui.findViewByTag('pop_personal_cancel');
    var confirm = ui.findViewByTag('pop_personal_confirm');
    var mCallback = null;
    initPopPersonal()

    this.show = function (callback) {
        user_input.setText('');
        pw_input.setText('');
        user_input.setError(null);
        pw_input.setError(null);
        pw.showAtLocation(activity.getWindow().getDecorView(), Gravity.CENTER, 0, 0);
        Attributes(0.6);
        mCallback = callback;
    }

    this.hide = function () {
        pw.dismiss();
    }

    this.setTitle = function (str) {
        ui.findViewByTag('pop_personal_title').setText(str);
    }

    this.setSubTitle = function (str) {
        ui.findViewByTag('pop_personal_subtitle').setText(str);
    }

    function Attributes(alpha) {
        lp.alpha = alpha;
        activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        activity.getWindow().setAttributes(lp);
    }

    function initPopPersonal() {
        user_input.setInputType(EditorInfo.TYPE_CLASS_TEXT);
        user_input.setImeOptions(EditorInfo.IME_ACTION_NEXT);
        pw_input.setInputType(EditorInfo.TYPE_CLASS_TEXT);
        pw_input.setImeOptions(EditorInfo.IME_ACTION_DONE);

        var params = root_view.getLayoutParams();
        params.width = w;
        root_view.setLayoutParams(params);

        params = ppl.getLayoutParams();
        params.width = parseInt(w * 0.7);
        ppl.setLayoutParams(params);

        params = cancel.getLayoutParams();
        params.width = parseInt((w * 0.7) / 2 - dp2px(1));
        cancel.setLayoutParams(params);

        params = confirm.getLayoutParams();
        params.width = parseInt((w * 0.7) / 2 - dp2px(1));
        confirm.setLayoutParams(params);

        ui.setEvent(root_view, 'click', function (view) {
            pw.dismiss();
        });

        ui.setEvent(cancel, 'click', function (view) {
            pw.dismiss();
        });

        ui.setEvent(confirm, 'click', function (view) {
            let ut = user_input.getText();
            let pt = pw_input.getText();
            if (ut == '') {
                user_input.setError('用户名不能为空');
                return;
            }
            if (pt == '') {
                pw_input.setError('密码不能为空');
                return;
            }
            mCallback(true, ut.toString(), pt.toString());
            mCallback = null;
            pw.dismiss();
        });

        let dp1 = dp2px(1);
        let dp5 = dp2px(5);

        var states = [[android.R.attr.state_focused], [-android.R.attr.state_focused]];
        var user_sld = new StateListDrawable();
        user_sld.addState(states[0], new CreateShape(dp5, 0, null, [dp1, "#000000"]));
        user_sld.addState(states[1], new CreateShape(dp5, 0, null, [dp1, "#5F000000"]));
        user_input.setBackground(user_sld);

        var pw_sld = new StateListDrawable();
        pw_sld.addState(states[0], new CreateShape(dp5, 0, null, [dp1, "#000000"]));
        pw_sld.addState(states[1], new CreateShape(dp5, 0, null, [dp1, "#5F000000"]));
        pw_input.setBackground(pw_sld);

        pw.setBackgroundDrawable(new BitmapDrawable());
        pw.setOutsideTouchable(true);
        pw.setFocusable(true);
        pw.setTouchable(true);

        var showSlide = new Slide(Gravity.BOTTOM);
        showSlide.setInterpolator(new OvershootInterpolator(0.8));
        showSlide.setDuration(300);
        pw.setEnterTransition(showSlide);

        var hideSlide = new Slide(Gravity.BOTTOM);
        hideSlide.setInterpolator(new AnticipateInterpolator(0.8));
        hideSlide.setDuration(300);
        hideSlide.setMode(Visibility.MODE_OUT);
        pw.setExitTransition(hideSlide);

        pw.setOnDismissListener({
            onDismiss: function () {
                if (mCallback != null) mCallback(false, null, null);
                mCallback = null;
                Attributes(1.0);
            }
        });
    }

}

function ColorEvaluator(fraction, startColor, endColor) {
    let inverseRation = 1 - fraction;
    let a = parseInt((endColor.a * fraction) + (startColor.a * inverseRation));
    let r = parseInt((endColor.r * fraction) + (startColor.r * inverseRation));
    let g = parseInt((endColor.g * fraction) + (startColor.g * inverseRation));
    let b = parseInt((endColor.b * fraction) + (startColor.b * inverseRation));
    return argb2str(a, r, g, b);
}

function argb2str(a, r, g, b) {
    let a1 = a.toString(16);
    let r1 = r.toString(16);
    let g1 = g.toString(16);
    let b1 = b.toString(16);
    if (a1.length == 1) a1 = '0' + a1;
    if (r1.length == 1) r1 = '0' + r1;
    if (g1.length == 1) g1 = '0' + g1;
    if (b1.length == 1) b1 = '0' + b1;
    return '#' + a1 + r1 + g1 + b1;
}

function str2argb(colorstr) {
    let cArr = colorstr.split('');
    let arr = new Array();
    let obj = new Object();
    for (i = 1; i < cArr.length; i += 2) {
        arr[arr.length] = '' + cArr[i] + cArr[i + 1];
    }
    if (arr.length == 3) {
        arr.unshift('FF');
    }
    obj.a = parseInt(arr[0], 16);
    obj.r = parseInt(arr[1], 16);
    obj.g = parseInt(arr[2], 16);
    obj.b = parseInt(arr[3], 16);
    return obj;
}

main();
/**
 * 该文件由EasyClick开发工具自动创建
 */

ui.layout("参数设置", "main.xml");
ui.float_switch.setChecked(false);
ui.float_switch.setEnabled(false);
ui.start();
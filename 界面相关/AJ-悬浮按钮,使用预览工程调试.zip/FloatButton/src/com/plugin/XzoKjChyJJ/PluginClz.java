package com.plugin.XzoKjChyJJ;

import android.content.Context;

public class PluginClz {

    public PluginClz(Context context){
        System.out.println("--- "+context);
    }

    public String test(){
           System.out.println("--- test method");
           return "我是测试方法";
    }

}

/*
 * @Author: 大柒
 * @QQ: 531310591@qq.com
 * @Date: 2020-07-31 04:45:27
 * @Version: EasyClick 5.0.0.RC12
 * @Description:
 * @LastEditors: 大柒
 * @LastEditTime: 2020-07-31 04:45:36
 */

importClass(android.os.Build);
importClass(android.view.Gravity);
importClass(android.view.WindowManager);
importClass(android.graphics.PixelFormat);

/**
 * 悬浮窗工具类
 * @param contentView
 * @constructor
 */
function FloatUtil(contentView) {
    let mWindowManager = context.getSystemService(context.WINDOW_SERVICE);
    let mHandler = ui.getHandler();
    let layoutParams = new WindowManager.LayoutParams();
    if (Build.VERSION.SDK_INT >= 26) {
        layoutParams.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
    } else {
        layoutParams.type = WindowManager.LayoutParams.TYPE_PHONE;
    }
    layoutParams.x = 0;
    layoutParams.y = 0;
    layoutParams.width = -2;
    layoutParams.height = -2;
    layoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
    layoutParams.gravity = Gravity.LEFT | Gravity.TOP;
    layoutParams.format = PixelFormat.RGBA_8888;

    MainPost(() => mWindowManager.addView(contentView, layoutParams));

    this.contentView = contentView;

    this.getX = function () {
        return layoutParams.x;
    }

    this.getY = function () {
        return layoutParams.y;
    }

    this.getWidth = function () {
        return layoutParams.width;
    }

    this.getHeight = function () {
        return layoutParams.height;
    }

    this.getScreenWidth = function () {
        return mWindowManager.getDefaultDisplay().getWidth();
    }

    this.getScreenHeight = function () {
        return mWindowManager.getDefaultDisplay().getHeight();
    }

    this.setSize = function (width, height) {
        layoutParams.width = width;
        layoutParams.height = height;
        updateViewLayout();
    }

    this.setPosition = function (x, y) {
        layoutParams.x = x;
        layoutParams.y = y;
        updateViewLayout();
    }

    this.setTouchable = function (touchable) {
        if (touchable) {
            layoutParams.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        } else {
            layoutParams.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        }
        updateViewLayout();
    }

    this.close = function () {
        MainPost(() => mWindowManager.removeView(contentView));
    }

    function MainPost(action) {
        mHandler.post({run: action});
    }

    function updateViewLayout() {
        MainPost(() => mWindowManager.updateViewLayout(contentView, layoutParams));
    }
}
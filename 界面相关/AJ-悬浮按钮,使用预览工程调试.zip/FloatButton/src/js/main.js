/*
 * @Author: 大柒
 * @QQ: 531310591@qq.com
 * @Date: 2020-07-31 04:45:27
 * @Version: EasyClick 5.0.0.RC12
 * @Description:
 * @LastEditors: 大柒
 * @LastEditTime: 2020-07-31 04:45:36
 */

function main() {
    toast('来自子线程的toast');
}

/** UI区域 */
//定义简易ui.run
ui.run = action => ui.getHandler().post({run: action});

let contentView = ui.getActivity().findViewById(android.R.id.content);
let fsv = contentView.findViewWithTag('float_switch');
ui.run(() => {
    fsv.setEnabled(true);
    ui.setEvent(fsv, "checkedChange", function (view, isChecked) {
        if (isChecked) {
            fb.show();
        } else {
            fb.hide();
        }
    });
});

setStopCallback(() => {
    fb.close();
    ui.run(() => {
        fsv.setChecked(false);
        fsv.setEnabled(false);
    });
});

/** 悬浮按钮 */
let fb = new FloatButton();
/* logo按钮参数 */
fb.setIcon('https://easyclick.gitee.io/assets/img/favicon.ico');
//按钮背景色
fb.setColor('#FFFFFF');

/* 添加item  建议不要超过6个按钮*/
fb.addItem('启动')
    .setIcon('file://./drawable/ic_play_arrow_black_48dp.png')
    .setTint('#FFFFFF')
    .setColor('#009688');
fb.addItem('按钮1')
    .setIcon('file://./drawable/ic_looks_1_black_48dp.png')
    .setTint('#FFFFFF')
    .setColor('#EF5350');
fb.addItem('按钮2')
    .setIcon('file://./drawable/ic_looks_2_black_48dp.png')
    .setTint('#FFFFFF')
    .setColor('#42A5F5');
fb.addItem('按钮3')
    .setIcon('file://./drawable/ic_looks_3_black_48dp.png')
    .setTint('#FFFFFF')
    .setColor('#42A5F5');
fb.addItem('按钮4')
    .setIcon('file://./drawable/ic_looks_4_black_48dp.png')
    .setTint('#FFFFFF')
    .setColor('#FDD835');
fb.addItem('关闭')
    .setIcon('@drawable/ic_close')
    .setColor('#C0C0C0')
    //如果在此处使用了onClick,此按钮将不会在item_click事件中触发
    .onClick(function (name, view) {
        fb.close();//关闭悬浮窗,并释放线程锁
        return true;
    });

/* 监听item点击*/
fb.on('item_click', (name, view) => {
    toast('点击了' + name);
    if (name == '启动') {
        thread.execAsync(main)//异步线程运行main方法
    }
    return false//false:菜单关闭 true:保持菜单开启
});

fb.on('show', () => {
    ui.logd('显示');
});

fb.on('hide', () => {
    ui.logd('隐藏');
});

let id1;
/* 监听菜单状态*/
fb.on('menu_state_change', isShow => {
    ui.logd('菜单' + (isShow ? '显示' : '隐藏'));
    //自定义功能 菜单显示5秒自动关闭
    if (isShow) {
        //如果菜单状态为显示,定时器五秒后关闭菜单
        id1 = setTimeout(() => {
            id1 = null;
            fb.menuHide();
        }, 5000);
    } else {
        //菜单关闭, 注销定时器
        if (id1 != null) cancelTimeout(id1);
        id1 = null;
    }
});

//此代码必须使用,目的为保持脚本运行.此代码要放在脚本最下面
fb.loop();

/*
 * @Author: 大柒
 * @QQ: 531310591@qq.com
 * @Date: 2020-07-31 04:45:27
 * @Version: EasyClick 5.0.0.RC12
 * @Description:
 * @LastEditors: 大柒
 * @LastEditTime: 2020-07-31 04:45:36
 */

importClass(android.widget.ImageView);
importClass(android.widget.FrameLayout);
importClass(android.widget.LinearLayout);
importClass(android.view.Gravity);
importClass(android.view.ViewGroup);
importClass(android.view.WindowManager);
importClass(android.view.animation.BounceInterpolator);
importClass(android.graphics.Color);
importClass(android.graphics.drawable.ColorDrawable);
importClass(android.graphics.drawable.BitmapDrawable);
importClass(android.graphics.drawable.GradientDrawable);
importClass(android.animation.Animator);
importClass(android.animation.AnimatorSet);
importClass(android.animation.ObjectAnimator);
importClass(android.os.Looper);
importClass(android.os.Handler);

/**
 * AJ悬浮按钮
 * @constructor
 */
function FloatButton() {
    Looper.prepare();
    const scale = context.getResources().getDisplayMetrics().density;
    let dp2px = dp => parseInt(Math.floor(dp * scale + 0.5));
    let px2dp = px => parseInt(Math.floor(px / scale + 0.5));
    let mWindowLogo, mWindowAnim, mWindowMenu;
    let mFloatPositionY = 0.5;
    let mLogoAlphas = [0.4, 0.8];
    let mButtonSize = dp2px(40);
    let mButtonPadding = dp2px(8);
    let mMenuRadius = dp2px(80);
    let mBitmapUtil = new BitmapUtil();
    let myHandler = new Handler(Looper.myLooper());
    let mHandler = ui.getHandler();
    let mItemUtil = new Object();
    let mXYList = new Array();
    let isShow = false;
    let isMenuOpen = false;
    let isAnimState = false;
    let isInitWindow = false;
    let mFloatPosition = false;
    let mAnim = new FloatAnimUtil();
    let mEventList = {
        show: new Function(),
        hide: new Function(),
        item_click: new Function(),
        menu_state_change: new Function()
    }

    initWindow();

    this.setIcon = function (path) {
        mWindowLogo.util.setIcon(path);
        mWindowAnim.util.setIcon(path);
    }

    this.setTint = function (colorstr) {
        MainPost(() => {
            mWindowLogo.util.setTint(colorstr);
            mWindowAnim.util.setTint(colorstr);
        });
    }

    this.setColor = function (colorstr) {
        MainPost(() => {
            mWindowLogo.util.setColor(colorstr);
            mWindowAnim.util.setColor(colorstr);
        });
    }

    this.addItem = function (name) {
        if (name == 'logo') {
            this.close();
            throw 'Error: FloatButton.addItem(Item名称不能为logo)';
        } else if (mItemUtil[name]) {
            this.close();
            throw 'Error: FloatButton.addItem(Item按钮名称重复,参数:' + name + ')';
        }
        let view = new ImageButtonView(name);
        view.setLayoutParams(new FrameLayout.LayoutParams(mButtonSize, mButtonSize, Gravity.CENTER_VERTICAL));
        MainPost(() => {
            mWindowMenu.contentView.addView(view);
            updateXYData();
        });
        mItemUtil[name] = new ViewUtil(view);
        return mItemUtil[name];
    }

    this.getItemView = function (name) {
        return findViewTag(mWindowMenu, name);
    }

    this.on = function (eventType, eventCallback) {
        mEventList[eventType] = eventCallback;
    }

    this.show = function (callback) {
        if (mWindowLogo == null) return;
        callback = callback || new Function();
        mAnim.show(callback);
    }

    this.hide = function (callback) {
        if (mWindowLogo == null) return;
        callback = callback || new Function();
        mAnim.hide(callback);
    }

    this.menuShow = function (callback) {
        if (mWindowLogo == null) return;
        callback = callback || new Function();
        if (isMenuOpen) {
            callback();
            return;
        }
        isShow ? menuShow() : mAnim.show(menuShow);

        function menuShow() {
            mAnim.menuShowOrHide(callback);
        }
    }

    this.menuHide = function (callback) {
        if (mWindowLogo == null) return;
        callback = callback || new Function();
        if (!isShow)
            callback();
        else if (!isMenuOpen)
            callback();
        else
            mAnim.menuShowOrHide(callback);
    }

    this.close = function () {
        if (mWindowLogo == null) return;
        mWindowLogo.close();
        mWindowMenu.close();
        mWindowAnim.close();
        myHandler.getLooper().quit();
        mWindowMenu = mWindowLogo = mWindowAnim = null;
    }

    this.loop = function () {
        Looper.loop();
    }


    /** 内部功能区*/

    function initWindow() {
        /** Menu*/
        let flMenu = new FrameLayout(context);
        mWindowMenu = new FloatUtil(flMenu);
        mWindowMenu.setSize(mMenuRadius + mButtonSize, mMenuRadius * 2 + mButtonSize);
        mWindowMenu.setTouchable(false);
        /** Anim*/
        let flAnim = new FrameLayout(context)
        let ivAnim = new ImageButtonView('logo');
        MainPost(() => flAnim.addView(ivAnim));
        mWindowAnim = new FloatUtil(flAnim);
        mWindowAnim.util = new ViewUtil(ivAnim);
        mWindowAnim.setSize(-1, -1);
        mWindowAnim.setTouchable(false);
        /** Logo*/
        let ivLogo = new ImageButtonView('logo');
        mWindowLogo = new FloatUtil(ivLogo);
        mWindowLogo.util = new ViewUtil(ivLogo);
        mWindowLogo.setSize(mButtonSize, mButtonSize);
        mWindowAnim.setTouchable(false);
        ivLogo.setOnTouchListener(new OnTouchListener());

        MainPost(() => {
            mWindowMenu.contentView.setVisibility(4);
            mWindowAnim.contentView.setVisibility(4);
            mWindowLogo.contentView.setVisibility(4);
            mWindowLogo.contentView.setAlpha(mLogoAlphas[0]);
            ivAnim.setAlpha(mLogoAlphas[0]);
            mWindowLogo.setPosition(-mButtonPadding, parseInt((mWindowAnim.getScreenHeight() - mButtonSize) * mFloatPositionY));
            updateMenuPosition();
        });
    }

    function findViewTag(window, tag) {
        return window.contentView.findViewWithTag(tag);
    }

    function MainPost(action) {
        mHandler.post({run: action});
    }

    /**
     * 圆形图标按钮
     * @param tag
     * @constructor
     */
    function ImageButtonView(tag) {
        let iv = new ImageView(context);
        let lp = new LinearLayout.LayoutParams(new ViewGroup.LayoutParams(mButtonSize, mButtonSize));
        iv.setLayoutParams(lp);
        MainPost(() => {
            iv.setTag(tag);
            iv.setPadding(mButtonPadding, mButtonPadding, mButtonPadding, mButtonPadding);
        });
        return iv;
    }

    /**
     * 控件工具类
     * @param view
     * @constructor
     */
    function ViewUtil(view) {
        let gd = new GradientDrawable();
        let dr = null;
        let bmp = null;
        let tint = null;
        let mClickCallback = ItemClickCallbak;
        gd.setShape(1);
        gd.setColor(Color.parseColor('#FFFFFF'));
        MainPost(() => {
                view.setBackground(gd);
                view.setOnClickListener({
                    onClick: () => {
                        if (view.getTag() == 'logo') return;
                        if (!mClickCallback(view.getTag(), view)) mAnim.menuShowOrHide();
                    }
                });
            }
        );

        this.setIcon = function (path) {
            if (bmp != null) bmp.recycle();
            bmp = mBitmapUtil.PathToBitmap(path);
            dr = new BitmapDrawable(bmp);
            if (tint != null) dr.setTint(Color.parseColor(tint));
            MainPost(() => view.setImageDrawable(dr));
            return this;
        }

        this.setTint = function (colorStr) {
            if (bmp == null) {
                tint = colorStr;
                return this;
            }
            dr.setTint(Color.parseColor(colorStr));
            return this;
        }

        this.setColor = function (colorstr) {
            MainPost(() => gd.setColor(Color.parseColor(colorstr)));
            return this;
        }

        this.onClick = function (action) {
            mClickCallback = action;
            return this;
        }
    }

    /**
     * Item按钮点击回调方法
     * @param tag
     * @param view
     * @constructor
     */
    function ItemClickCallbak(tag, view) {
        return !!mEventList.item_click(tag, view);
    }

    /**
     * 更新item坐标数据
     */
    function updateXYData() {
        let count = mWindowMenu.contentView.getChildCount();
        let angle = 360 / (count * 2 - 2);
        let degree = 0;
        let x, y;
        mXYList = new Array();
        for (let i = 0; i < count; i++) {
            x = parseInt(0 + Math.cos(Math.PI * 2 / 360 * (degree - 90)) * mMenuRadius);
            y = parseInt(0 + Math.sin(Math.PI * 2 / 360 * (degree - 90)) * mMenuRadius);
            if (Math.abs(x) < 10) x = 0;
            if (Math.abs(y) < 10) y = 0;
            mXYList.push([{x: x, y: y}, {x: -x, y: y}]);
            degree += angle;
        }
    }

    /**
     * 更新Menu菜单位置
     */
    function updateMenuPosition() {
        let mv = mWindowMenu.contentView;
        let y = parseInt(mWindowLogo.getY() - (mWindowMenu.getHeight() - mButtonSize) / 2);
        let x = parseInt(mFloatPosition ? mWindowLogo.getX() - mv.getWidth() + (mButtonSize / 2) : mWindowLogo.getX() + (mButtonSize / 2));
        mWindowMenu.setPosition(x, y);
    }

    /**
     * 监听触摸事件
     * @returns {function(...[*]=)} OnTouchListener
     * @constructor
     */
    function OnTouchListener() {
        let x, y, windowX, windowY, isMove;
        return function (view, event) {
            if (isAnimState) return true;
            switch (event.getAction()) {
                case event.ACTION_DOWN:
                    x = event.getRawX();
                    y = event.getRawY();
                    windowX = mWindowLogo.getX();
                    windowY = mWindowLogo.getY();
                    isMove = false;
                    return true;
                case event.ACTION_MOVE:
                    if (!isMove) {
                        if (Math.abs(event.getRawX() - x) > 30 || Math.abs(event.getRawY() - y) > 30) {
                            MainPost(() => view.setAlpha(mLogoAlphas[1]));
                            isMove = true;
                        }
                    } else if (!isMenuOpen) {
                        mWindowLogo.setPosition(windowX + (event.getRawX() - x), windowY + (event.getRawY() - y));
                    }
                    return true;
                case event.ACTION_UP:
                    if (!isMove) {
                        mAnim.menuShowOrHide();
                    } else if (isMove && !isMenuOpen) {
                        mFloatPosition = mWindowAnim.contentView.getWidth() / 2 < event.getRawX();
                        mAnim.position();
                    }
                    return true;
            }
        }
    }

    /**
     * 动画工具类
     * @constructor
     */
    function FloatAnimUtil() {
        let position = false;
        let tx = (v, a) => ObjectAnimator.ofFloat(v, "translationX", a);
        let ty = (v, a) => ObjectAnimator.ofFloat(v, "translationY", a);
        let ap = (v, a) => ObjectAnimator.ofFloat(v, "alpha", a);
        let sx = (v, a) => ObjectAnimator.ofFloat(v, "scaleX", a);
        let sy = (v, a) => ObjectAnimator.ofFloat(v, "scaleY", a);
        let al = (a, f) => a.addListener(new Animator.AnimatorListener({onAnimationEnd: f}));

        function AnimStart(data, time) {
            let animator = new AnimatorSet();
            animator.playTogether(data);
            animator.setDuration(time);
            animator.start();
            return animator;
        }

        this.show = function (callback) {
            if (isShow) {
                callback();
                return;
            }
            isShow = true;
            let lv = mWindowLogo.contentView;
            let mv = mWindowMenu.contentView;
            let av = mWindowAnim.contentView;
            let data = mFloatPosition ? [mButtonSize, 0] : [-mButtonSize, 0];
            MainPost(() => {
                lv.setVisibility(4);
                av.setVisibility(4);
                mv.setVisibility(4);
                lv.setTranslationX(data[0]);
                lv.setVisibility(0);
                al(AnimStart([tx(lv, data)], 500), () => {
                    mWindowLogo.setTouchable(true);
                    callback();
                    mEventList.show();
                });
            });
        }

        this.hide = function (callback) {
            if (!isShow) {
                callback();
                return;
            }
            isShow = false;
            isMenuOpen ? this.menuShowOrHide(hide) : hide();

            function hide() {
                let lv = mWindowLogo.contentView;
                let data = mFloatPosition ? [0, mButtonSize] : [0, -mButtonSize];
                MainPost(() => {
                    al(AnimStart([tx(lv, data)], 500), () => {
                        mWindowAnim.contentView.setVisibility(8);
                        mWindowMenu.contentView.setVisibility(8);
                        mWindowLogo.contentView.setVisibility(8);
                        mWindowLogo.setTouchable(false);
                        callback();
                        mEventList.hide();
                    });
                });
            }
        }

        this.menuShowOrHide = function (callback) {
            callback = callback || new Function();
            let mv = mWindowMenu.contentView;
            let count = mv.getChildCount();
            let e = mFloatPosition ? 1 : 0;
            let animList = new Array();
            let itemView, data;
            isAnimState = true;
            mWindowMenu.setTouchable(!isMenuOpen);
            for (let i = 0; i < count; i++) {
                itemView = mv.getChildAt(i);
                data = isMenuOpen ? [1, 0] : [0, 1];
                animList.push(tx(itemView, getX(i)));
                animList.push(ty(itemView, getY(i)));
                animList.push(sx(itemView, data));
                animList.push(sy(itemView, data));
            }
            MainPost(() => {
                mv.setVisibility(0);
                al(AnimStart(animList, 200), () => {
                    isAnimState = false;
                    if (isMenuOpen) mv.setVisibility(8);
                    mWindowLogo.contentView.setAlpha(mLogoAlphas[isMenuOpen ? 0 : 1]);
                    isMenuOpen = !isMenuOpen;
                    callback();
                    mEventList.menu_state_change(isMenuOpen);
                });
            });

            function getX(i) {
                return isMenuOpen ? [mXYList[i][e].x, 0] : [0, mXYList[i][e].x];
            }

            function getY(i) {
                return isMenuOpen ? [mXYList[i][e].y, 0] : [0, mXYList[i][e].y];
            }
        }

        this.position = function (callback) {
            callback = callback || new Function();
            let x = mWindowLogo.getX();
            let y = mWindowLogo.getY();
            let w = mWindowAnim.contentView.getWidth();
            let data = mFloatPosition ? [x, w - mButtonSize + mButtonPadding] : [x, 0 - mButtonPadding];
            let lv = mWindowLogo.contentView;
            let av = findViewTag(mWindowAnim, 'logo');
            MainPost(() => {
                mWindowAnim.contentView.setVisibility(0);
                av.setVisibility(4);
                av.setTranslationX(x);
                av.setTranslationY(y);
                av.setAlpha(mLogoAlphas[0]);
                av.setVisibility(0);
                lv.setVisibility(4);
                lv.setAlpha(0);
                mWindowLogo.setPosition(data[1], y);
                let animTx = tx(av, data);
                animTx.setInterpolator(new BounceInterpolator());//动画插值器
                al(AnimStart([animTx], 300), () => {
                    lv.setVisibility(0);
                    position = mFloatPosition;
                    setTimeout(() => {
                        MainPost(() => {
                            al(AnimStart([ap(av, [mLogoAlphas[0], 0]), ap(lv, [0, mLogoAlphas[0]])], 300), () => {
                                mWindowAnim.contentView.setVisibility(8);
                            })
                        });
                    }, 17);
                    updateMenuPosition();
                });
            });
            /** 停靠方向发生改变,改变所有item重力位置*/
            if (position != mFloatPosition) {
                let mv = mWindowMenu.contentView;
                let gravity = Gravity.CENTER_VERTICAL | (mFloatPosition ? Gravity.RIGHT : Gravity.LEFT);
                let count = mv.getChildCount();
                let itemView, lp;
                MainPost(() => {
                    for (let i = 0; i < count; i++) {
                        itemView = mv.getChildAt(i);
                        lp = itemView.getLayoutParams();
                        lp.gravity = gravity;
                        itemView.setLayoutParams(lp);
                    }
                });
            }
        }
    }
}

importClass(java.io.File);
importClass(java.io.FileInputStream);
importClass(java.net.URL);
importClass(android.graphics.BitmapFactory);

/**
 * Bitmap工具类
 * @constructor
 */
function BitmapUtil() {
    let resources = context.getResources();

    this.PathToBitmap = function (path) {
        let bmp = null;
        let value;
        if (path.indexOf('@drawable/') != -1) {
            value = path.replace('@drawable/', '');
            bmp = resources.getDrawable(getResID(value)).getBitmap();
        } else if (path.indexOf('file://./') != -1) {
            value = path.replace('file://./', '');
            bmp = uiWrapper.resResAsBitmap(value);
        } else if (path.indexOf('file://') != -1) {
            value = path.replace('file://', '');
            bmp = BitmapFactory.decodeStream(new FileInputStream(value));
        } else if (isURL(path)) {
            let fileUrl = new URL(path);
            let conn = fileUrl.openConnection();
            conn.setDoInput(true);
            conn.connect();
            let is = conn.getInputStream();
            bmp = BitmapFactory.decodeStream(is);
            is.close();
        }
        return bmp;
    }

    function getResID(name) {
        return resources.getIdentifier(name, "drawable", 'com.gibb.easyclick');
    }

    function isURL(str) {
        let pattern = new RegExp('^(https?:\\/\\/)?' + // protocol
            '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.?)+[a-z]{2,}|' + // domain name
            '((\\d{1,3}\\.){3}\\d{1,3}))' + // OR ip (v4) address
            '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*' + // port and path
            '(\\?[;&a-z\\d%_.~+=-]*)?' + // query string
            '(\\#[-a-z\\d_]*)?$', 'i'); // fragment locator
        return pattern.test(str);
    }
}
<template>
	<view>

		<swiper class="card-swiper" :class="dotStyle?'square-dot':'round-dot'" :indicator-dots="true" :circular="true"
		 :autoplay="true" interval="5000" duration="500" @change="cardSwiper" indicator-color="#8799a3"
		 indicator-active-color="#0081ff">
			<swiper-item v-for="(item,index) in swiperList" :key="index" :class="cardCur==index?'cur':''">
				<view class="swiper-item">
					<image :src="item.url" mode="aspectFill" v-if="item.type=='image'"></image>
					<video :src="item.url" autoplay loop muted :show-play-btn="false" :controls="false" objectFit="cover" v-if="item.type=='video' "></video>
				</view>
			</swiper-item>
		</swiper>
		<scroll-view scroll-x class="bg-white nav text-center fixed" :style="[{top:2 + 'px'}]">
			<view class="cu-item" :class="index==TabCur?'text-blue cur':''" v-for="(item,index) in tabNav" :key="index" @tap="tabSelect"
			 :data-id="index">
				{{tabNav[index]}}
			</view>
		</scroll-view>
		<block v-if="TabCur==0">
			<view>
				<form>
					<view class="cu-form-group">
						<view class="title">授权码</view>
						<input placeholder="输入作者给你的授权码" name="input" v-model="textKey"></input>
					<button class="cu-btn bg-green shadow" @tap="showModal"  data-target="buttonKey">点我授权</button>

					</view>
					<view class="cu-modal" :class="modalName=='buttonKey'?'show':''">
						<view class="cu-dialog">
							<view class="cu-bar bg-white justify-end">
								<view class="content">授权码</view>
								<view class="action" @tap="hideModal">
									<text class="cuIcon-close text-red"></text>
								</view>
							</view>
							<view class="padding-xl">
								请联系作者拿到授权码
							</view>
						</view>
					</view>
					<view class="cu-form-group">
						<view class="title">验证消息</view>
						<input placeholder="请输入添加好友的验证消息" name="input" v-model="textareaAValue"></input>
					</view>
					<view class="cu-form-group">
						<view class="title">备注</view>
						<input placeholder="请输入备注名称" name="input"  v-model="runNum"></input>
					</view>
					<view class="cu-form-group">
						<view class="title">运行次数</view>
						<input placeholder="请添加几位好友" name="input" type="number" v-model="clickLike"></input>
					</view>

			<view class="cu-form-group margin-top">
				<view class="title">运行模式</view>
				<picker @change="PickerChange" :value="index" :range="picker">
					<view class="picker">
						{{index>-1?picker[index]:'请选择'}}
					</view>
				</picker>
			</view>



					<view class="padding flex flex-direction">
						<button class="cu-btn bg-gradual-red margin-tb-sm lg" @click="openFlow">打开悬浮窗</button>
						<button class="cu-btn bg-gradual-red margin-tb-sm lg" @click="changeEdit">保存配置</button>
						<button class="cu-btn bg-gradual-blue margin-tb-sm lg" @click="stcartPhoneText">打开手机文本(下载WPS编辑文本)</button>
						<button class="cu-btn bg-gradual-blue margin-tb-sm lg" @click="closeFlow">打开输入法设置(安卓10用)</button>
					</view>
					<!-- !!!!! placeholder 在ios表现有偏移 建议使用 第一种样式 -->
				</form>
			</view>
		</block>
		<block v-if="TabCur==1">
			<view class="cu-bar bg-white  solid-bottom margin-top solid-bottom">
				<view class="action">
					<text class="cuIcon-title text-blue"></text>脚本执行参数
				</view>
			</view>
			<view class="bg-white">
				<view class="flex flex-wrap padding solid-top">
					<view class="basis-df">添加好友次数</view>
					<view class="basis-df" v-model="clickLike">{{clickLike}} 次</view>
				</view>
			</view>

		</block>
		<block v-if="TabCur==2">




		<view class="cu-bar bg-white margin-top">
			<view class="action">
				<text class="cuIcon-title text-orange "></text> 联系方式
			</view>
			<view class="action">
				<button class="cu-btn bg-green shadow" @tap="showModal" data-target="Image">名片</button>
			</view>
		</view>
		<view class="cu-modal" :class="modalName=='Image'?'show':''">
			<view class="cu-dialog">
				<!-- http://shp.qpic.cn/collector/771667481/e99a2e0c-9ec4-4449-ae82-8b8f76c9b786/0 -->
				<view class="bg-img" style="background-image: url('https://li771667481.oss-cn-shanghai.aliyuncs.com/img/wxpng.png');height:500px;">
					<view class="cu-bar justify-end text-white">
						<view class="action" @tap="hideModal">
							<text class="cuIcon-close "></text>
						</view>
					</view>
				</view>
				<view class="cu-bar bg-white">
					<view class="action margin-0 flex-sub  solid-left" @tap="hideModal">我知道了</view>
				</view>
			</view>
		</view>
		
		

	
	
		</block>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				swiperList: [{
					id: 0,
					type: 'image',
					url: 'https://li771667481.oss-cn-shanghai.aliyuncs.com/yxlm/1.jpg'
				}, {
					id: 1,
					type: 'image',
					url: 'https://li771667481.oss-cn-shanghai.aliyuncs.com/yxlm/2.jpg',
				}, {
					id: 2,
					type: 'image',
					url: 'https://li771667481.oss-cn-shanghai.aliyuncs.com/yxlm/3.jpg'
				}, {
					id: 3,
					type: 'image',
					url: 'https://li771667481.oss-cn-shanghai.aliyuncs.com/yxlm/4.jpg'
				}, {
					id: 4,
					type: 'image',
					url:  'https://li771667481.oss-cn-shanghai.aliyuncs.com/yxlm/5.jpg'
				}, {
					id: 5,
					type: 'image',
					url: 'https://li771667481.oss-cn-shanghai.aliyuncs.com/yxlm/6.jpg'
				}, {
					id: 6,
					type: 'image',
					url:  'https://li771667481.oss-cn-shanghai.aliyuncs.com/yxlm/7.jpg'
				}],
			
				CustomBar: this.CustomBar,
				modalName: null,
				index: 0, //下拉框
				picker: ['微信加好友', '微信加群'], //下拉框选项
			

				checkbox: [{ //多选框
					value: '点赞',
					checked: false
				}, {
					value: '分享',
					checked: true
				}],
				
				textareaAValue: '', //激活码内容
				runNum: null, //备注
				clickLike: null, //循环次数

				TabCur: 0, //TAB选项卡，0是第一个d
				tabNav: ['配置界面', '运行参数', '关于我们']
			};
		},
		onLoad() {
			const json3 = this.readJson('scriptConfig', '') //读取并解析json
			this.textareaAValue = json3.aCode //激活码框
			this.runNum = json3.runNum //备注
			this.clickLike = json3.clickLike//循环次数
			this.index = json3.aMode //下拉框
			this.textKey = json3.aCodeKey //授权
			const json4 = this.readJson('checked', '') //读取并解析多选框
			this.checkbox[0].checked = json4[0].checked
			this.checkbox[1].checked = json4[1].checked
			
			

		},
		methods: {

			readConfig: function(key, defaultValue) {

				var value = window.ec.getConfig(key)
				if (value == null) {
					return defaultValue;
				} else {
					return value;
				}
			},
			saveConfig: function(key, value) {
				window.ec.saveConfig(key, value)
			},
			readJson: function(key) {
				return JSON.parse(this.readConfig(key, ''))
			},
			saveJson: function(key, value) {
				window.ec.saveConfig(key, JSON.stringify(value))
			},

			tabSelect(e) { //不要动，这个是选项卡响应函数
				this.TabCur = e.currentTarget.dataset.id;
				this.scrollLeft = (e.currentTarget.dataset.id - 1) * 60
			},
			changeEdit() {
				const checked = JSON.stringify(this.checkbox) //转换成字符串
				const scriptConfig = {
					"aCode": this.textareaAValue, //验证好友消息
					"aMode": this.index, //下拉选项
					"runNum": this.runNum, //运行次数
					"clickLike": this.clickLike,//添加好友次数
					'aCodeKey':this.textKey,
				
				}
				console.log("scriptConfig", JSON.stringify(scriptConfig))
				console.log("checked", checked)
				uni.showToast({
					title: '保存成功',
					duration: 2000
				});
				//脚本基础配置，记得取消掉注释
				window.ec.saveConfig("scriptConfig", JSON.stringify(scriptConfig))
				//多选框配置
				window.ec.saveConfig("checked", checked)
				window.ec.saveConfig('intentInputModule','false') ///打开输入法
				window.ec.saveConfig('phoneText','false') //打开文本
				window.ec.saveConfig('buttonKey','false')//授权
			},
			openFlow() {

				
			},
			closeFlow() {
				window.ec.toast("我是toast消息")  ;
				window.ec.saveConfig('intentInputModule','true')
				window.ec.start()


			},
			stcartPhoneText(){
				window.ec.saveConfig('phoneText','true')
				window.ec.start()

			},

			PickerChange(e) { //下拉框
				this.index = e.detail.value
				console.log("下拉框:" + e.detail.value.toString())

			},

			cardSwiper(e) {
				
				this.cardCur = e.detail.current
			},
			
			
			showModal(e) {
				this.modalName = e.currentTarget.dataset.target
				if(this.modalName == 'buttonKey'){
			
					
					
					window.ec.saveConfig('buttonKey','true')
					window.ec.start()
				}

			},
			hideModal(e) {
				this.modalName = null
			},
			

		}
	}
</script>

<style>
	page {
		padding-top: 30px;
	}

	.tower-swiper .tower-item {
		transform: scale(calc(0.5 + var(--index) / 10));
		margin-left: calc(var(--left) * 100upx - 150upx);
		z-index: var(--index);
	}
</style>

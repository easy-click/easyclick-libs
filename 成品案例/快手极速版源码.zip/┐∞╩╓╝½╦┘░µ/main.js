/*
第一次写ec   第一次接触js  感谢群友支持
撸码大佬请看下一句：
	生姜擦洗头皮可以止脱生发，欧力给
*/

//初始化UI数据
let UI数据 = getConfigJSON();
logd(JSON.stringify(UI数据));

//判断起始快手and截止快手是否为空
if (UI数据.qishizhanghao = "undefined") {
    logd("请输入起始账号");
    exit();//退出脚本
}
if (UI数据.jiezhizhanghao = "undefined") {
    logd("请输入截止账号");
    exit();//退出脚本
}
//判断激活码是否正确，不要瞎搞！！！
let 提交激活码网址 = "http://bailiang.tunnel1.legutech.com:8091/system/code/encde?code=2342";
let 返回值 = http.httpGetDefault(url, 10 * 1000, {"User-Agent": "test"});
    //如果 <= 0 就说明激活码错误
if (返回值.indexOf("激活码可用") <= 0) {
    logd("激活码为空or激活码错误or激活码到期，联系管理员");
    exit();//退出脚本
}
打码();
//主控制线程
function main() {
    //异步线程（多线程，第二个执行线程），启动息屏亮屏
    thread.execAsync(function() {
        do {
            息屏亮屏();
        }while (true)
    });
    //异步线程(也就是大周天循环，任务线程)
    thread.execAsync(function() {
        do {
            大周天循环();
        }while (true)
    });
    //主线程，检测脚本是否卡主，如果卡主，停止前面哪两个异步线程，重新开始执行
    do {
        sleep(1000)
    }while (true)
}
function 大周天循环() {
    //打开不同的分身
    //先检查有多少个应用
    for (let i = parseInt(UI数据.jiezhizhanghao);i>=parseInt(UI数据.jiezhizhanghao);i--){
        utils.openAppByName("快手极速版"+i);
        //这里要把i传入小周天循环
        if (UI数据.feixing = true) {
            卡飞行();
        }
        function 小周天循环() { //分身内部任务
            utils.openAppByName("快手极速版");

            if (UI数据.qiandao = true) {
                自动签到();//自动签到，有个坐标，需要点击xy，没完成
            }
            看视频();//看视频，这个应该加个时间控制，函数里面调用打码
        }
    }
}
function 自动签到() {
    let 红包= id("com.kuaishou.nebula:id/red_packet").getOneNodeInfo(1000);
    if (红包) {
        红包.click();
        /*
        这个地方，会有一个加载的过程，时间不定，用do循环
        点击立即签到
         */
        do {
            let 立即签到= desc("立即签到").getOneNodeInfo(500);
            if (立即签到) {
                立即签到.click();
                break;
            }
            sleep(500)
        }while (true)

    //关闭坐标：123,338

        //点击返回
        do {
            let 返回= desc("返回").getOneNodeInfo(500);
            if (返回) {
                返回.click();
                break;
            }
            sleep(500)
        }while (true)

    }
};
function 卡飞行() {
    /*
    * 1、弹出状态栏
    * 2、再次滑动下拉状态栏
    * 3、打开飞行模式
    * 4、延时60秒
    * 5、关闭飞行模式
    * */
    //1、弹出状态栏
    let 打开状态栏 = openNotification();
    if (打开状态栏){
        toast("打开状态栏成功");
    } else {
        toast("打开状态栏失败");
    }
    sleep(2000)
    //2、再次滑动下拉状态栏
    logd("打开二级状态栏：" + swipeToPoint(487,865,487,1681,500));
    //3、打开飞行模式
    do {
        if (click(text("飞行模式"))) {
            logd("点击飞行模式成功");
            break;
        }
        logd("检测“飞行模式”");
        sleep(1000)
    }while (true);
    //4、延时60秒
    for (let i = 60; i > 0; i--) {
        sleep(1000);
        logd("暂停倒计时："+i);
    };
    //5、关闭飞行模式
    do {
        if (click(text("飞行模式"))) {
            logd("点击飞行模式成功");
            break;
        }
        logd("检测“飞行模式”");
        sleep(1000)
    }while (true);
}
function 看视频() {
    let selectors = id("com.kuaishou.nebula:id/user_name_text_view_new");
    let result = swipe(selectors,300,300,200);
    if (result){
        toast("滑动成功");
    } else {
        toast("滑动失败");
    }
    let 分割停留 = UI数据.tingliu.split('/');
    let 随机看视频时间=random(parseInt(分割停留[0]),parseInt(分割停留[1]));
    for (let i = 随机看视频时间;i>0;i-- ){
        sleep(1000);
        logd("随机看视频倒计时："+i);
    }
}
function 打码(){
    //判断是否有滑块出现
    if (text("滑块验证")) {
        //有滑块出现
        logd("出现滑块");
        //申请截图权限
        let request = image.requestScreenCapture();
        if (request){
            toast("申请成功");
        }else {
            toast("申请失败");
        }
        //判断手机型号是否等于
        if (device.getModel()=="Redmi Note 4X") {
            //区域截图
            let imageX = image.captureScreen(); //屏幕截图
            logd("截图结果："+imageX);
            let r = image.clip(imageX,42,226,1031,802);//裁剪图片
            toast("r: "+r);
            logd("uuid:"+r.uuid)

            let 转=image.toBase64(r);
            toast("result123 "+转);
            转=转+"";
            let 坐标返回 = 联众("联众账号","联众密码",转);
            logd("坐标返回："+ 坐标返回);
        }
    }
//下面写需要滑动的坐标，快手是滑块，所以我这里就不演示了
}
function 联众(username, password, img) {

    logd("username:"+username);
    logd("password:"+password);
    var r = img
    var url = "https://v2-api.jsdama.com/upload";
    var pa = {
        softwareId: 14589,
        softwareSecret: "LsKF2ERj2qDTst8eVeZiWGGoew88AdzsuIFrgzTA",
        username: username,
        password: password,
        captchaData: r,
        captchaType: 1310,
        captchaMinLength: 0,
        captchaMaxLength: 0,
        workerTipsId: 0
    };
    do {
        var x = http.postJSON(url, pa, 10 * 1000, {"User-Agent": "test"});
        toast(" 联众返回值     " + x);
        if (x != null) {
            break;
        }
    }while (true)
    var d =JSON.parse(x);
    toast("json:"+d);
    logd("坐标属性:"+d.data.recognition);
    return d.data.recognition;
}
//完成
function 息屏亮屏(){
    //息屏操作
    let 息屏 =agentEvent.closeScreen();
    for (let i = UI数据.xiping; i>0;i--){
        sleep(1000)
        logd(i);
    }
    //亮屏操作
    var 亮屏 =agentEvent.lightScreen();
    for (let i = UI数据.liangping; i>0;i--){
        sleep(1000)
        logd(i);
    }


}
//红米note 4X  未完成  还有两个机型
function 清理后台(){
    var result = recentApps();
    if (result){
        toast("成功111");

        do {
           if (click(id("com.android.systemui:id/clearButton"))){
               break;
           }
            sleep(1000)
        }while (true)
    } else {
        toast("失败1111");
    }
}

